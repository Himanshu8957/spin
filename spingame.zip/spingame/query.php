
<?php
include_once('db_config.php');

if(@$_POST['requestfor'] == 'SaveRegistraionData'){
    
    $usercode = $_POST["usercode"];
    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
    $phone = $_POST["phone"];


    // Check if user already exists
    $query = "SELECT * FROM users WHERE phone = '$phone'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        echo json_encode(["status" => "duplicate", "message" => "User already registered"]);
    } else {
        $insertQuery = "INSERT INTO users (usercode, fname, lname, phone) VALUES ('$usercode', '$fname', '$lname', '$phone')";

        if (mysqli_query($conn, $insertQuery)) {
            echo json_encode(["status" => "success", "message" => "User successfully registered"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error registering user. Please try again later."]);
        }
    }
}
if(@$_POST['requestfor'] == 'SaveGameData'){

    $usercode = $_POST['usercode'];
    $prize = $_POST['prize'];
    $gamestatus = $_POST['gamestatus'];

    $query = mysqli_query($conn,"UPDATE `users` SET `prize`='$prize',`status`='$gamestatus' WHERE usercode = '$usercode'");
}


?>


