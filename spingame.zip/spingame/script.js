       
       
       function savespindata(prize) {
        var usercode = $("#usercode").val();
        var requestfor = 'SaveGameData';
        let gamestatus;
    
        if (prize == 'Bad Luck') {
            gamestatus = 'Loser';
        } else {
            gamestatus = 'Winner';
        }
    
        $.ajax({
            url: "query.php",
            type: "post",
            data: {
                usercode: usercode,
                prize: prize,
                gamestatus: gamestatus,
                requestfor: requestfor
            },
            success: function (data, status) {
              setCookie("Spin//Completed", !0, 30);
            },
            error: function (xhr, status, error) {
                console.error("AJAX request failed:", status, error);
            }
        });
    }
    

       
       function create_spinner() {
          color_data = ['#00FF00', '#fdb441', '#fd6930', '#eb5454', '#bf9dd3', '#29b8cd', "#00f2a6", "#f67", "#28282B"];
          label_data = ['i Phone', 'Bag', 'Back Cover', 'Smart Watch', 'EareBuds', 'Sunglasses', 'T-Shirt', 'Lunch Box', 'Bad Luck'];
          var color = color_data;
          var label = label_data;
          var slices = color.length;
          var sliceDeg = 360 / slices;
          var deg = rand(0, 360);
          var speed = 10;
          var slowDownRand = 0;
          var ctx = canvas.getContext('2d');
          var width = canvas.width; // size
          var center = width / 2; // center
          ctx.clearRect(0, 0, width, width);
          for (var i = 0; i < slices; i++) {
            ctx.beginPath();
            ctx.fillStyle = color[i];
            ctx.moveTo(center, center);
            ctx.arc(center, center, width / 2, deg2rad(deg), deg2rad(deg + sliceDeg));
            ctx.lineTo(center, center);
            ctx.fill();
            var drawText_deg = deg + sliceDeg / 2;
            ctx.save();
            ctx.translate(center, center);
            ctx.rotate(deg2rad(drawText_deg));
            ctx.textAlign = "center";
            ctx.fillStyle = "#fff";
            ctx.font = 'bold 14px sans-serif';
            ctx.fillText(label[i], 100, 5);
            ctx.restore();
            deg += sliceDeg;
          }
        }
        create_spinner();
        var deg = rand(0, 360);
        var speed = 10;
        var ctx = canvas.getContext('2d');
        var width = canvas.width; // size
        var center = width / 2; // center
        var isStopped = false;
        var lock = false;
        var slowDownRand = 0;
      
        function spin() {
          var username = $("#username").val();
          var wheelaudio = document.getElementById('wheelaudio');
          wheelaudio.play();
          color_data = ['#00FF00', '#fdb441', '#fd6930', '#eb5454', '#bf9dd3', '#800000', "#00f2a6", "#f67", "#28282B"];
          label_data = ['i Phone', 'Bag', 'Back Cover', 'Smart Watch', 'EareBuds', 'Sunglasses', 'T-Shirt', 'Lunch Box', 'Bad Luck'];
          var color = color_data;
          var label = label_data;
          var slices = color.length;
          var sliceDeg = 360 / slices;
          deg += speed;
          deg %= 360;

          setTimeout(function() {
            isStopped = true;
            wheelaudio.pause();
          }, 3600)
          // Increment speed
          if (!isStopped && speed < 3) {
            speed = speed + 1 * 0.1;
          }
          // Decrement Speed
          if (isStopped) {
            if (!lock) {
              lock = true;
              slowDownRand = rand(0.8, 0.9);
            }
            speed = speed > 0.2 ? speed *= slowDownRand : 0;
          }
          // Stopped!
          if (lock && !speed) {
            var applauseaudio = document.getElementById('applauseaudio');
           
            var ai = Math.floor(((360 - deg - 90) % 360) / sliceDeg); // deg 2 Array Index
            ai = (slices + ai) % slices; // Fix negative index
            //return alert("You got:\n"+ label[ai] ); // Get Array Item from end Degree
            if(label[ai] == 'Bad Luck'){
            //   return swal({
            //   title: "Sorry!!",
            //   text: "Its Your Bad Luck",
            //   type: "success",
            //   confirmButtonText: "OK",
            //   closeOnConfirm: false
            // });
              return $("#result_popup").css({
                'display': 'flex'
              }),
              $("#result_content").css({'border': '4px solid #000'}),
              $("#user_name").html(username),
              $("#prize_text").html(label[ai]),
              $("#result_image").attr("src", "images/sorry.png"),
              $("#status_text").html('You Lost'),
              $("#status_text").css({'margin-top' : '40px'}),
              $("#right-popper, #left-popper").hide(),
              $("#status_text").css({'color': '#DE3163'}),
              $("#result_content").css("background", "#f5f5f5"),
              savespindata(label[ai]);
            }
           
            else {
              applauseaudio.play();
             
              return setTimeout(function () {
                 $("#result_popup").css({
                    'display': 'flex'
                })

                $("#result_content").css({'border': '4px solid #000'});
                $("#prize_text").html(label[ai]);
                $("#result_content").css({
                    "background": "url('images/ribbon.gif') center/cover, #f5f5f5"
                });            
                $("#user_name").html(username);
                $("#status_text").html('You Won');
                $("#result_image").attr("src", "images/congratulations.gif");
                $("#right-popper, #left-popper").show();
                $("#status_text").css({'color': '#21aa38'});
                savespindata(label[ai]);
              }, 500);
          
             
              
             
          }
          
          
          }
          ctx.clearRect(0, 0, width, width);
          for (var i = 0; i < slices; i++) {
            ctx.beginPath();
            ctx.fillStyle = color[i];
            ctx.moveTo(center, center);
            ctx.arc(center, center, width / 2, deg2rad(deg), deg2rad(deg + sliceDeg));
            ctx.lineTo(center, center);
            ctx.fill();
            var drawText_deg = deg + sliceDeg / 2;
            ctx.save();
            ctx.translate(center, center);
            ctx.rotate(deg2rad(drawText_deg));
            ctx.textAlign = "center";
            ctx.fillStyle = "#fff";
            ctx.font = 'bold 14px sans-serif';
            ctx.fillText(label[i], 100, 5);
            ctx.restore();
            deg += sliceDeg;
          }
          window.requestAnimationFrame(spin);
        }
      
        function stops() {
            isStopped = true;
        }
      
        function deg2rad(deg) {
          return deg * Math.PI / 180;
        }
      
        function rand(min, max) {
          return Math.random() * (max - min) + min;
        }

////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////AJAX Part Starts/////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
        function generateRandomCode(length) {
          const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
          let code = '';

          for (let i = 0; i < length; i++) {
            const randomIndex = Math.floor(Math.random() * characters.length);
            code += characters.charAt(randomIndex);
          }

          return code;
        }



        function setCookie(e, t, a) {
          let s = new Date();
          s.setTime(s.getTime() + 864e5 * a);
          let l = "expires=" + s.toUTCString();
          document.cookie = e + "=" + t + "; " + l + "; path=/";
        }


        function getCookie(e) {
          let t = e + "=",
            a;
          return (
            decodeURIComponent(document.cookie)
              .split("; ")
              .forEach((e) => {
                0 === e.indexOf(t) && (a = e.substring(t.length));
              }),
            a
          );
        }

        function runcookie() {
          getCookie("registraion//Done") && (document.getElementById("intro").style.display = "none");
          getCookie("Spin//Completed") && (document.getElementById("result_popup").style.display = "flex") 
          && (document.getElementById("result_popup").style.background = "#000")
          && (document.getElementById("result_content").style.display = "none")
          && (document.getElementById("result_close_btn").style.display = "none")
          && (document.getElementById("thankyou_content").style.display = "")
          && (document.getElementById("playagain_btn").style.display = "");
        }

        function resetall(){
          document.cookie = 'registraion//Done' + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
          document.cookie = 'Spin//Completed' + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
          window.location.href = 'index.php';
        }

        $(document).ready(function() {
          $("#submit-button").on("click", function() {
            // Get form data
            var fname = $("#fname").val();
            var lname = $("#lname").val();
            var phone = $("#phone").val();
            var city = $("#city").val(); 

            // Client-side validation
            if (fname === "") {
              $(".error-fname").html("First Name cannot be empty.");
              return;
            }
            else{
              $(".error-fname").html("");
            }
            if (lname === "") {
              $(".error-lname").html("Last Name cannot be empty.");
              return;
            }
            else{
              $(".error-lname").html("");
            }
            if (phone === "") {
              $(".error-phone").html("Phone cannot be empty.");
              return;
            }
            else if (!/^\d+$/.test(phone)) {
              $(".error-phone").html("Invalid Phone number.");
              return;
            }
            else if (phone.length > 10 || phone.length < 10 ) {
              $(".error-phone").html("Phone must have 10 digits.");
              return;
            }
            else {
              $(".error-phone").html("");
            }
            if (city === "") {
              $(".error-city").html("City cannot be empty.");
              return;
            }
            else{
              $(".error-city").html("");
            }
      

            submitData();
         
          });
        });

        function submitData() {
          $("#submit-button").html("<i class='fa fa-refresh fa-spin'></i>");
          var usercode = generateRandomCode(8);
          var fname = $("#fname").val();
          var lname = $("#lname").val();
          var username = fname + " " + lname;
          var phone = $("#phone").val();
          var city = $("#city").val(); 
          var requestfor = 'SaveRegistraionData'; 
      
          $.ajax({
              type: "POST",
              url: "query.php", 
              data: {
                  usercode : usercode,
                  fname: fname,
                  lname: lname,
                  phone: phone,
                  city: city,
                  requestfor: requestfor
              },
              success: function(response) {
                  try {
                      var jsonData = JSON.parse(response);
      
                      // Check the status in the JSON data
                      if (jsonData.status === 'success') {
                          // Handle success
                          setTimeout(function() {
                              $("#submit-button").html("<i class='fa fa-check'></i> Done");
                              $(".error-message").text(jsonData.message);
                              $(".error-message").css({
                                  'color': "green",
                              });
                          }, 1000)
      
                          setTimeout(function() {
                              $("#content").fadeOut();
                              $("#intro").fadeOut();
                              setCookie("registraion//Done", !0, 30);
                              window.location.href = window.location.href + '?user=' + usercode + '&name=' + username ;
                          }, 1500)
                          console.log(jsonData.message);
                      }
                      else {
                          setTimeout(function() {
                              $("#submit-button").html("Submit");
                              $(".error-message").text(jsonData.message);
                              $(".error-message").css({
                                color: "red",
                              });
                              console.log(jsonData.message);
                          }, 1000)
                          
                      }
                  } catch (e) {
                      $("#submit-button").html("<i class='fa fa-times'></i> Error");
                      $(".error-message").text('Error registering user. Please try again later.');
                      $(".error-message").css({
                          color: "red",
                      });
                      console.error('Error in catch block:', $(".error-message").text());
                  }
              },
              error: function() {
                  $("#submit-button").html("<i class='fa fa-times'></i> Error");
                  $(".error-message").html("Error submitting data. Please try again.");
              }
          });
      }
      

        function clicktostart() {
            $("#welcome_intro").fadeOut();
            $("#content").css({'display' : 'flex'});
        }


      
      