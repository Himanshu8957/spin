<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "spinwheel";

// $servername = "localhost";
// $username = "u278847502_spinwheel";
// $password = "Spin@123#";
// $dbname = "u278847502_spinwheel";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if($conn){
    // echo "Connection established";
}
else{
    echo "Connection failed";
}
?>