<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="viewport" content="width=device-width" />
    <title>Spin Wheel Game</title>
    <!--important library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" integrity="sha512-b2QcS5SsA8tZodcDtGRELiGv5SaKSk1vDHDaQRda0htPYWZ6046lr3kJ5bAAQdpV2mmA/4v0wQF9MyU6/pDIAg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  </head>
  <body style="overflow: hidden;" onload="runcookie();">
    <div class="main_container">
    <input type="hidden" id="usercode" value="<?php echo @$_GET['user'] ?>">
    <input type="hidden" id="username" value="<?php echo @$_GET['name'] ?>">
     
      <div id="wheel">
        <img src="" class="spin_structure" alt="">
        <canvas id="canvas" width="350px" height="350px"></canvas>
        <button type="button" class="spin-button" onclick="spin()"><img src="spin-arrow.png" alt=""></button>
      </div>
    </div>

    <div class="result_popup" id="result_popup">
      <div class="result_content" id="result_content">
        <div><img src="" id="result_image" class="Congracts-badge" alt=""></div>
        <h4 class="text-center fw-bold" id="user_name"></h4>
        <h1 class="text-center" id="status_text"></h1>
        <h3 class="text-center" id="prize_text"></h3>

      </div>
      <button id="result_close_btn" type="button" onclick="runcookie();" class="btn btn-warning mt-3 text-white">Click Here</button>

      <div class="thankyou_content" id="thankyou_content" style="display:none">
          <h3 class="text-center text-dark mb-3">Thank You</h3>

      <button id="playagain_btn" type="button" onclick="resetall()" class="btn btn-info text-white mt-2">Play Again</button>
      </div>
      
    </div>


    <div class="spin_intro" id="intro">
      <div class="welcome_intro" id="welcome_intro">
          <h2 class="text-center my-3">Welcome to  Spin Game</h2>
          <button type="button" class="btn btn-primary" onclick="clicktostart()">Click Now</button>
      </div>
      
      <div class="content" id="content">
          <div class="cascading-right" >
            <div class="p-3 shadow-5">
              <h2 class="fw-bold mb-5 text-center">Register Here.</h2>
              <div class="row">
                <div class="col-md-12 mb-2">
                  <div class="form-group mb-2">
                    <input type="text" class="form-control" id="fname" placeholder="First Name">
                    <div class="error-msg error-fname" style="color: red; font-size: 13px;"></div>
                  </div>
                </div>
                <div class="col-md-12 mb-2">
                  <div class="form-group mb-2">
                    <input type="text"  class="form-control" id="lname" placeholder="Last Name"/>
                    <div class="error-msg error-lname" style="color: red; font-size: 13px;"></div>
                  </div>
                </div>
                <div class="col-md-12 mb-2">
                  <div class="form-group mb-2">
                    <input type="tel"  class="form-control" id="phone" placeholder="Phone"/>
                    <div class="error-msg error-phone" style="color: red; font-size: 13px;"></div>
                  </div>
                </div>
               
              </div>

              <div class="form-group text-center">
                <button type="button" id="submit-button" class="btn btn-primary my-2 p-2 fs-6">
                  Submit
                </button>
                <div class="error-msg error-message" style="font-size: 20px;"></div>
              </div>
            </div>
          </div>
      </div>
    </div>

    <!-- <audio controls="controls" id="applauseaudio" src="./applause.mp3" type="audio/mp3" style="display: none;"></audio>
    <audio controls="controls" id="wheelaudio" src="./wheel.mp3" type="audio/mp3" style="display: none;"></audio> -->


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.min.js" integrity="sha512-WW8/jxkELe2CAiE4LvQfwm1rajOS8PHasCCx+knHG0gBHt8EXxS6T6tJRTGuDQVnluuAvMxWF4j8SNFDKceLFg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script type="text/javascript" src="script.js"></script>

  </body>
</html>